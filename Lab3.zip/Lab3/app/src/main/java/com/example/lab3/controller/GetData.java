package com.example.lab3.controller;


import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import androidx.lifecycle.ViewModelProvider;
import androidx.recyclerview.widget.RecyclerView;
import com.example.lab3.models.Country;
import java.util.ArrayList;
import com.android.volley.RequestQueue;
import com.android.volley.Request;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;
import com.example.lab3.R;
import android.util.Log;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;


import com.example.lab3.ui.notifications.NotificationsFragment;
import com.example.lab3.ui.notifications.NotificationsViewModel;

public class GetData {
    private final String TAG = "NOW";
    private String URL = "https://restcountries.eu/rest/v1/all";

    public RecyclerView.Adapter adapter;
    public RecyclerView recyclerView;
    private NotificationsViewModel notificationsViewModel;
    private RequestQueue queue;

    public static ArrayList<Country> countryList = new ArrayList<Country>();
    public GetData(RecyclerView recyclerView, RecyclerView.Adapter adapter, RequestQueue queue, NotificationsFragment notificationsFragment){

        notificationsViewModel = new ViewModelProvider(notificationsFragment).get(NotificationsViewModel.class);
        this.queue = queue;
        this.adapter = adapter;
        this.recyclerView = recyclerView;
    }

    public void loadCountryData(){
        StringRequest stringRequest = new StringRequest(Request.Method.GET, URL,
                new Response.Listener<String>() {
                    //@Override
                    public void onResponse(String response) {
                        try {

                            JSONArray array = new JSONArray(response);
                            Log.i("Payal", "size: " + String.valueOf(array.length()));
                            for (int i = 0; i < array.length(); i++) {

                                JSONObject jsonData = array.getJSONObject(i);

                                String name = jsonData.getString("name");
                                String capital = jsonData.getString("capital");
                                String region = jsonData.getString("region");
                                String subregion = jsonData.getString("subregion");
                                String population = jsonData.getString("population");
                                String timezones = jsonData.getString("timezones");

                                Country country = new Country(name, capital, region, subregion, population, timezones);
                                countryList.add(country);
                            }
                            recyclerView.setAdapter(adapter);

                        } catch (JSONException e) {
                            e.printStackTrace();
                        }

                    }
                },
                new Response.ErrorListener() {
                    @Override
                    public void onErrorResponse(VolleyError error) {
                    }
                });
        queue.add(stringRequest);
    }


}


