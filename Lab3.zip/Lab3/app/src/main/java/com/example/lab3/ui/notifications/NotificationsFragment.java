package com.example.lab3.ui.notifications;

import android.content.ClipData;
import android.os.Bundle;
import android.util.Log;
import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.annotation.StringRes;
import androidx.fragment.app.Fragment;
import androidx.lifecycle.Observer;
import androidx.lifecycle.ViewModelProvider;
import androidx.lifecycle.ViewModelProviders;
import androidx.recyclerview.widget.DefaultItemAnimator;
import androidx.recyclerview.widget.LinearLayoutManager;
import androidx.recyclerview.widget.RecyclerView;
import com.example.lab3.R;
import com.example.lab3.controller.GetData;
import com.example.lab3.controller.ItemRecycleViewer;
import com.example.lab3.controller.GetData;
import com.example.lab3.models.Country;
import android.widget.Button;
import com.android.volley.Request;
import com.android.volley.RequestQueue;
import com.android.volley.Response;
import com.android.volley.VolleyError;
import com.android.volley.toolbox.StringRequest;
import com.android.volley.toolbox.Volley;


import com.example.lab3.R;

import org.json.JSONArray;
import org.json.JSONException;
import org.json.JSONObject;

import java.util.ArrayList;

public class NotificationsFragment extends Fragment {

    private NotificationsViewModel notificationsViewModel;
    private RecyclerView recyclerView;
    private ArrayList<Country> countryList;
    private ItemRecycleViewer itemRecycleViewer;
    private RecyclerView.Adapter adapter;
    private RequestQueue queue;

    private String URL = "https://restcountries.eu/rest/v1/all";

    @Override
    public void onCreate(Bundle myBundle) {
        super.onCreate(myBundle);
        //notificationsViewModel = new ViewModelProvider(this).get(NotificationsViewModel.class);
        //queue = Volley.newRequestQueue(getContext());
    }


    public View onCreateView(@NonNull LayoutInflater inflater,
                             ViewGroup container, Bundle savedInstanceState) {
        notificationsViewModel =
                new ViewModelProvider(this).get(NotificationsViewModel.class);

        View root = inflater.inflate(R.layout.fragment_notifications, container, false);
        //countryList = new ArrayList<>();

        adapter = new ItemRecycleViewer(R.layout.cardview_layout, GetData.countryList);
        queue = Volley.newRequestQueue(getContext());
        itemRecycleViewer = new ItemRecycleViewer(R.layout.cardview_layout, GetData.countryList);
        recyclerView = root.findViewById(R.id.my_recycle_view);

        recyclerView.setLayoutManager(new LinearLayoutManager(getContext()));
        recyclerView.setItemAnimator(new DefaultItemAnimator());
        recyclerView.setAdapter(adapter);

        GetData getData = new GetData(recyclerView, adapter, queue, this);
        //loadCountryData();
        getData.loadCountryData();
        adapter.notifyDataSetChanged();
        return root;
    }
}


