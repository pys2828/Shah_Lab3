package com.example.lab3.ui.details;

import androidx.lifecycle.ViewModel;

public class DetailsViewModel extends ViewModel {
    // TODO: Implement the ViewModel
}