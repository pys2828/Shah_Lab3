package com.example.lab3.models;

import android.os.Bundle;
import android.view.View;
import android.util.Log;

import androidx.navigation.Navigation;
import androidx.recyclerview.widget.RecyclerView;
import android.widget.TextView;
import com.example.lab3.R;


public class ViewHolder extends RecyclerView.ViewHolder implements View.OnClickListener{
    public TextView name;
    public TextView capital;
    public TextView region;

    private String TAG = "VIEW_HOLDER";
    private Bundle bundle;

    public ViewHolder(View itemView){
        super(itemView);
        itemView.setOnClickListener(this);
        name = itemView.findViewById(R.id.item_country);
        capital = itemView.findViewById(R.id.item_capital);
        region = itemView.findViewById(R.id.item_region);

    }


    @Override
    public void onClick(View view){
        Log.i(TAG, "you clicked" + String.valueOf(view.getId()).toString());
        bundle = new Bundle();
        bundle.putInt("card", getAdapterPosition());

        bundle.putString("capital", capital.getText().toString());
        bundle.putString("region", region.getText().toString());
        bundle.putString("capital", capital.getText().toString());
        Navigation.findNavController(itemView).navigate(R.id.action_navigation_notifications_to_detailsFragment, bundle);


    }
}
