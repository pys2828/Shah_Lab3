package com.example.lab3.ui.notifications;

import androidx.lifecycle.LiveData;
import androidx.lifecycle.MutableLiveData;
import androidx.lifecycle.ViewModel;
import com.example.lab3.models.Country;
import java.util.ArrayList;

public class NotificationsViewModel extends ViewModel {

    private MutableLiveData<String> mText;
    private MutableLiveData<ArrayList<Country>> countryList;


    public NotificationsViewModel() {
        mText = new MutableLiveData<>();
        mText.setValue("This is notifications fragment");

        countryList = new MutableLiveData<>();
        //this was ArrayList<>() originally
        countryList.setValue(new ArrayList<Country>());

    }

    public MutableLiveData<ArrayList<Country>> getCountryList(){
        return countryList;
    }
    public void addCountryList(ArrayList<Country> myCountryList){
        countryList.postValue(myCountryList);
    }

    public LiveData<String> getText() {
        return mText;
    }
}