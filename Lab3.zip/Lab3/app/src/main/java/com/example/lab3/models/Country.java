package com.example.lab3.models;

public class Country {
    public String name;
    public String capital;
    public String region;
    public String subregion;
    public String population;
    public String timezones;

    public Country(String name, String capital, String region, String subregion, String population, String timezones){
        this.name = name;
        this.capital = capital;
        this.region = region;
        this.subregion = subregion;
        this.population = population;
        this.timezones = timezones;
    }

    public String getName(){
        return this.name;
    }

    public String getCapital(){
        return this.capital;
    }

    public String getRegion() {return this.region;}
}
