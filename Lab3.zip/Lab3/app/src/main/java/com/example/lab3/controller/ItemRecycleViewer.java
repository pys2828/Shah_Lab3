package com.example.lab3.controller;

import android.view.LayoutInflater;
import android.widget.TextView;
import android.view.View;
import android.view.ViewGroup;

import androidx.annotation.NonNull;
import androidx.recyclerview.widget.RecyclerView;
import com.example.lab3.models.Country;
import com.example.lab3.models.ViewHolder;

import java.util.ArrayList;

public class ItemRecycleViewer extends RecyclerView.Adapter<ViewHolder>{

    private int layout_view;
    private ArrayList<Country> countryList;
    public ItemRecycleViewer (int layout_view, ArrayList<Country> countryList){
        this.layout_view = layout_view;
        this.countryList = countryList;
    }
    @NonNull
    @Override
    public ViewHolder onCreateViewHolder(@NonNull ViewGroup parent, int viewType){
        View view = LayoutInflater.from(parent.getContext()).inflate(layout_view, parent, false);
        ViewHolder viewHolder = new ViewHolder(view);

        return viewHolder;
    }

    @Override
    public void onBindViewHolder(@NonNull ViewHolder holder, int position){
        TextView name = holder.name;
        TextView capital = holder.capital;
        TextView region = holder.region;
        name.setText(countryList.get(position).name);  //getters from Country class
        capital.setText(countryList.get(position).capital);
        region.setText(countryList.get(position).region);

    }

    @Override
    public int getItemCount() {
        return  countryList.size();
    }
}
