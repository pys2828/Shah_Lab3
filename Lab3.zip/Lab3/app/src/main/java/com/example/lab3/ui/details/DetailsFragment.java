package com.example.lab3.ui.details;

import androidx.lifecycle.ViewModelProvider;

import android.os.Bundle;
import android.util.Log;

import androidx.annotation.NonNull;
import androidx.annotation.Nullable;
import androidx.fragment.app.Fragment;
import com.example.lab3.models.Country;
import com.example.lab3.controller.GetData;

import android.view.LayoutInflater;
import android.view.View;
import android.view.ViewGroup;
import android.widget.TextView;

import com.example.lab3.R;
import com.example.lab3.ui.notifications.NotificationsViewModel;

public class DetailsFragment extends Fragment {

    private DetailsViewModel mViewModel;
    private NotificationsViewModel notificationsViewModel;

    public static DetailsFragment newInstance() {
        return new DetailsFragment();
    }

    @Override
    public View onCreateView(@NonNull LayoutInflater inflater, @Nullable ViewGroup container,
                             @Nullable Bundle savedInstanceState) {
        return inflater.inflate(R.layout.details_fragment, container, false);
    }

    @Override
    public void onViewCreated(View view, Bundle savedInstanceState){
        TextView countryView = view.findViewById(R.id.detail_name);
        TextView capitalView = view.findViewById(R.id.capital);
        TextView subregView = view.findViewById(R.id.subregion);
        TextView popView = view.findViewById(R.id.population);
        TextView timeView = view.findViewById(R.id.timezones);
        Bundle bundle = getArguments();
        int position = bundle.getInt("card");
        Country country = GetData.countryList.get(position);
        Log.i("name", country.name);
        countryView.setText(country.name);
        capitalView.setText(country.capital);
        subregView.setText(country.subregion);
        popView.setText(country.population);
        timeView.setText(country.timezones);
    }

    @Override
    public void onActivityCreated(@Nullable Bundle savedInstanceState) {
        super.onActivityCreated(savedInstanceState);
        mViewModel = new ViewModelProvider(this).get(DetailsViewModel.class);
        // TODO: Use the ViewModel
    }

}